/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wsBank;

import classes.Clientes;
import com.google.gson.Gson;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.POST;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

/**
 * REST Web Service
 *
 * @author cc44800199875
 */
@Path("Clientes")
public class ClientesResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of BankResource
     */
    public ClientesResource() {
    }
    
    //Retorna Cliente pelo id
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("{id}")
    public String getCliente(@PathParam("id") int id) throws SQLException, ClassNotFoundException {
        //TODO return proper representation object
        Clientes c = new Clientes();
        c.getCliente(id);
        Gson json = new Gson();
        String resultado = json.toJson(c);
        return resultado;
    }
    
    //Retorna Lista de Clientes
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getClientes() throws SQLException, ClassNotFoundException {
        //TODO return proper representation object
        ArrayList<Clientes> lista;
        Clientes c = new Clientes();
        lista = c.getClientes();
        Gson json = new Gson();
        String resultado = json.toJson(lista);
        return resultado;
    }

    //Retorna Cliente pelo nome
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/nome/{nome}")
    public String getClienteNome(@PathParam("nome") String nome) throws SQLException, ClassNotFoundException {
        //TODO return proper representation object
        Clientes c = new Clientes();
        ArrayList<Clientes> lista = c.getClienteNome(nome);
        Gson json = new Gson();
        String resultado = json.toJson(c);
        return resultado;
    }

    //Insere um novo cliente
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String postCliente(String content) throws SQLException{
        Gson json = new Gson();
        Clientes c = json.fromJson(content, Clientes.class);
        return c.inserir();
    }
    
    //Deleta um cliente pelo ID
    @DELETE
    @Produces(MediaType.TEXT_PLAIN)
    @Path("{id}")
    public String deletar(@PathParam("id") int idCliente) throws SQLException {
        //TODO return proper representation object
        Clientes c = new Clientes();
        return c.delete(idCliente);
    }    
    
    /**
     * PUT method for updating or creating an instance of AlunosResource
     * @param content representation for the resource
     */
    //Altera os dados do cliente
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    public String putCliente(String content) throws SQLException {
        Gson json = new Gson();
        Clientes c = json.fromJson(content, Clientes.class);
        return c.alterar();
    }
    
    /**
     * PUT method for updating or creating an instance of AlunosResource
     * @param content representation for the resource
     */
    @PUT
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/saque/{id},{valor}")
    public String putSaque(@PathParam("id") int id, @PathParam("valor") int valor) throws SQLException, ClassNotFoundException {
        //TODO return proper representation object
        Clientes c = new Clientes();
        return c.saque(id, valor);
    }
    
    /**
     * PUT method for updating or creating an instance of AlunosResource
     * @param content representation for the resource
     */
    @PUT
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/dep/{id},{valor}")
    public String putDeposito(@PathParam("id") int id, @PathParam("valor") int valor) throws SQLException, ClassNotFoundException {
        //TODO return proper representation object
        Clientes c = new Clientes();
        return c.deposito(id, valor);
    }
}
