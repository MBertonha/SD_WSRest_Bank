package classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/**
 *
 * @author cc44800199875
 */
public class Clientes {

    /**
     * @return the idCliente
     */
    public int getIdCliente() {
        return idCliente;
    }

    /**
     * @param idCliente the idCliente to set
     */
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the saldo
     */
    public int getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    /**
     * @return the senha
     */
    public int getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(int senha) {
        this.senha = senha;
    }
    private int idCliente;
    private String nome;
    private int saldo;
    private int senha;
    
    
    public void getCliente(int Id) throws SQLException, ClassNotFoundException{
        Connection conn = ConectaBank.getConexaoMySQL();
        PreparedStatement stmt = null;
        try
        {
            stmt = conn.prepareStatement("select * from clientes where idCliente=?");
            stmt.setLong(1, Id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()){
                this.setNome(rs.getString("nome"));
                this.setSenha(rs.getInt("senha"));
                this.setSaldo(rs.getInt("saldo"));
                this.setIdCliente(rs.getInt("idCliente"));
                rs.close();
            }
        }finally {
            if (stmt != null){
                stmt.close();
            }            
        }
    }
    
     public ArrayList<Clientes> getClienteNome(String nome) throws SQLException, ClassNotFoundException{
        ArrayList<Clientes> lista = new ArrayList<>();
        Connection conn = ConectaBank.getConexaoMySQL();
        PreparedStatement stmt = null;
        stmt = conn.prepareStatement("select * from clientes where nome=?");
        stmt.setString(1, nome);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Clientes c = new Clientes();
            c.setNome(rs.getString("nome"));
            c.setSenha(rs.getInt("senha"));
            c.setSaldo(rs.getInt("saldo"));
            c.setIdCliente(rs.getInt("idCliente"));
            lista.add(c);
        }

        if (stmt != null) {
            stmt.close();
        }
        return lista;
    }
     
     public String inserir() throws SQLException{
        Connection conn = ConectaBank.getConexaoMySQL();
        //banco.CriaConecta();
        String sql = "INSERT INTO clientes(nome, senha, saldo) VALUES(?,?,?)";     
        String retorno = "erro";
        try {
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, this.getNome());
            pst.setInt(2, this.getSenha());
            pst.setInt(3, this.getSaldo());
            
            if(pst.executeUpdate()>0)
            {
                retorno = "ok";
            }                            
            
        } catch (SQLException ex) {
           // Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = ex.getMessage();
        }
        return retorno;
    }
    
    public String alterar() throws SQLException
    {
        Connection conn = ConectaBank.getConexaoMySQL();
        String sql = "UPDATE clientes " +
                     "   SET nome=?, senha=?, saldo=? " +
                     " WHERE idCliente=? ";     
        String retorno = "erro";
        try {
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, this.getNome());
            pst.setInt(2, this.getSenha());            
            pst.setInt(3, this.getSaldo());
            pst.setInt(4, this.getIdCliente());
            
            if(pst.executeUpdate()>0)
            {
                retorno = "ok";
            }                            
            
        } catch (SQLException ex) {
           // Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = ex.getMessage();
        }
        return retorno;    
    }
    
    public String delete(int ID) throws SQLException
    {
        Connection conn = ConectaBank.getConexaoMySQL();
        String sql = " DELETE FROM clientes " +
                     " WHERE idCliente = ?" ;     
        String retorno = "erro";
        try {
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, ID);           
            if(pst.executeUpdate()>0)
            {
                retorno = "ok";
            }                            
            
        } catch (SQLException ex) {
           // Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            //retorno = ex.getMessage();
        }
        return retorno;    
    }
    
    public String saque(int ID, int valor) throws SQLException{
        
        int saldoAtual = 0;
        int saldoNovo = 0;
        String retorno = "erro";
        
        Connection conn = ConectaBank.getConexaoMySQL();
        String sqlSelect = "SELECT saldo FROM clientes WHERE idCliente = " + ID;
        
        
        PreparedStatement stmt = conn.prepareStatement(sqlSelect);
        ResultSet rs = stmt.executeQuery(sqlSelect);
        
        
        while(rs.next()){
            saldoAtual = rs.getInt("saldo");
        }        
        saldoNovo = saldoAtual - valor;        
                 
        if (saldoNovo < 0){
            retorno = "Vai poder sacar não cara";
            return retorno;
        }else{
            saldoAtual = saldoAtual - valor;
            String sql = "UPDATE clientes SET saldo ='" + saldoAtual + "' WHERE idCliente = idCliente= " + ID;
           
            try {
                PreparedStatement stmt2 = conn.prepareStatement(sqlSelect);
                ResultSet rs2 = stmt2.executeQuery(sqlSelect);
                
                PreparedStatement pst = conn.prepareStatement(sql);          
            
                if(pst.executeUpdate()>0)
                {
                    retorno = "ok";
                }                            
            
            } catch (SQLException ex) {
           // Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = ex.getMessage();
            }
            return retorno; 
        }         
    }
    
    public String deposito(int ID, int valor) throws SQLException{
        
        int saldoAtual = 0;
        int saldoNovo = 0;
        String retorno = "erro";
        
        Connection conn = ConectaBank.getConexaoMySQL();
        String sqlSelect = "SELECT saldo FROM clientes WHERE idCliente= " + ID;
        
        PreparedStatement stmt = conn.prepareStatement(sqlSelect);
        ResultSet rs = stmt.executeQuery(sqlSelect);
        while(rs.next()){
            saldoAtual = rs.getInt("saldo");
        }        
        saldoNovo = saldoAtual + valor;              
       
        String sql = "UPDATE clientes SET saldo ='" + saldoNovo + "' WHERE idCliente = idCliente= " + ID;
           
            try {
                PreparedStatement stmt2 = conn.prepareStatement(sqlSelect);
                ResultSet rs2 = stmt2.executeQuery(sqlSelect);
                
                PreparedStatement pst = conn.prepareStatement(sql);            
            
                if(pst.executeUpdate()>0)
                {
                    retorno = "ok";
                }                            
            
            } catch (SQLException ex) {
           // Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            //retorno = ex.getMessage();
            retorno = "Vai poder dopositar não cara";
            }
            return retorno;          
    }
    
        public ArrayList<Clientes> getClientes() throws SQLException, ClassNotFoundException{
        Connection conn = ConectaBank.getConexaoMySQL();
        PreparedStatement stmt = null;
        ArrayList<Clientes> lista = new ArrayList<>();

        stmt = conn.prepareStatement("select * from alunos");
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Clientes a = new Clientes();
            a.setIdCliente(rs.getInt("idClientes"));
            a.setNome(rs.getString("nome"));
            a.setSenha(rs.getInt("senha"));
            a.setSaldo(rs.getInt("saldo"));
            lista.add(a);
        }
        rs.close();
        if (stmt != null) {
            stmt.close();
        }
        return lista;
    }
}
